import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { SearchPipe } from './pipe/search.pipe';

@NgModule({
  declarations: [
  ],
  imports: [
    HttpClientModule,
  ],
})
export class AuthModule { }
