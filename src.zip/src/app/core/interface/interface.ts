export interface name{
  firstname:string
}
