export enum loginControlNames {
  firstname = 'firstname',
  lastname = 'lastname',
  email = 'email',
  password = 'password',
  confirmPassword = 'confirmPassword'
}
